Run the NLP_3.py code first

You’ll get a 6 files as output:

1. Vocab.txt file
2. hmm.JSON file

3. greedy_dev.out is greedy prediction on dev data
4. greedy.out is greedy prediction on test data

5. viterbi_dev.out is Viterbi prediction on dev data
6. viterbi.out is Viterbi prediction on test data


Then to check for greedy evaluation accuracy on development data:
python eval.py -p greedy_dev.out -g data/dev	
Then to check for Viterbi evaluation accuracy on development data:
python eval.py -p viterbi_dev.out -g data/dev


Or

You could run the .ipynb file 	
	